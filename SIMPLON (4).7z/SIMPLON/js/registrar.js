function validaciones(id_input,id_span,enviar) {
    var name = document.getElementById(id_input).value;
    if (name.length < 2) {
        document.getElementById(id_span).classList.add("error")
        document.getElementById(id_span).innerHTML = "Ponga un nombre mas largo"
        document.getElementById(enviar).disabled=true;
    }
   
    else {
        document.getElementById(id_span).classList.remove("error")
        document.getElementById(id_span).innerHTML = "";
        document.getElementById(enviar).disabled=false;
    }

    }

    function validarcoder(id_input,id_span,enviar) {
        var name = document.getElementById(id_input).value;
        if (name.length < 2) {
            document.getElementById(id_span).classList.add("error")
            document.getElementById(id_span).innerHTML = "Ponga mas caracteres"
            document.getElementById(enviar).disabled=true;
        }
        else {
            document.getElementById(id_span).classList.remove("error")
            document.getElementById(id_span).innerHTML = "";
            document.getElementById(enviar).disabled=false;
        }
    
      }

function validarDni(){
  var dni=''
  if(!(/^\d{8}[a-zA-Z]$/.test(dni))){
    dni = document.getElementById('dni').value;
  }
  
  //Se separan los números de la letra
  var letraDNI = dni.substring(8, 9).toUpperCase();
  var numDNI = parseInt(dni.substring(0, 8));
  
  //Se calcula la letra correspondiente al número
  var letras = ['T', 'R', 'W', 'A', 'G', 'M', 'Y', 'F', 'P', 'D', 'X', 'B', 'N', 'J', 'Z', 'S', 'Q', 'V', 'H', 'L', 'C', 'K', 'E', 'T'];
  var letraCorrecta = letras[numDNI % 23];
  
  if(letraDNI!= letraCorrecta){
    document.getElementById('enviar').disabled=true;
    alert("Has introducido una letra incorrecta");
  
  } 
}

var ok = true;
var d = 0;
var m = 0;
var a = 0;
function validarF(d, m, a,) {

  if ((a < 1950) || (a > 2050) || (m < 1) || (m > 12) || (d < 1) || (d > 31)){
  document.getElementById('enviar').disabled=true;
    ok = alert("fecha no es valida");

    }else {
    if ((a % 4 != 0) && (m == 2) && (d > 28)){

      document.getElementById('enviar').disabled=true;
      ok = alert("fecha no es valida");
     } else {
      if ((((m == 4) || (m == 6) || (m == 9) || (m == 11)) && (d > 30)) || ((m == 2) && (d > 29))){
        document.getElementById('enviar').disabled=true;
        ok = alert("fecha no es valida");
    }
  }
    }
  return ok;

}
    
